function handler () {
    EVENT_DATA=$1

    seq 1 1000 | xargs -n1 -P 1000 curl $TEST
}
